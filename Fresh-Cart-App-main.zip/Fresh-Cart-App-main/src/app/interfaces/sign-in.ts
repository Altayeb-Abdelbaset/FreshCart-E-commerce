export interface SignIn {
    name: string;
    password: string;
}
